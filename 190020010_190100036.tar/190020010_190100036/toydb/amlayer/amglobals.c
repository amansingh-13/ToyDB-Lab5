# include "am.h"

int AM_RootPageNum = 0;
int AM_LeftPageNum = 0;
int AM_Errno;

